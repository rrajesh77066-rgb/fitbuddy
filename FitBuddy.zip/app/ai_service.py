"""Gemini integration with a safe local fallback when no API key is configured."""
import os
from google import genai

def _client():
    key = os.getenv("GOOGLE_API_KEY", "").strip()
    return genai.Client(api_key=key) if key else None

def _generate(prompt: str, model: str, fallback: str) -> str:
    client = _client()
    if not client:
        return fallback + "\n\n[Demo mode: Add GOOGLE_API_KEY to .env to enable Gemini-generated content.]"
    try:
        response = client.models.generate_content(model=model, contents=prompt)
        text = getattr(response, "text", None)
        return text.strip() if text else fallback
    except Exception as exc:
        return fallback + f"\n\n[Gemini unavailable: {exc}]"

def generate_workout_gemini(username: str, age: int, weight: float, goal: str, intensity: str) -> str:
    prompt = f"""Create a safe, beginner-friendly 7-day fitness plan for {username}, age {age}, weight {weight} kg.
Goal: {goal}. Preferred intensity: {intensity}.
For each day include warm-up, main activity with sets/reps or duration, and cooldown/recovery.
Include rest/recovery days and remind the user to stop if they feel pain. Avoid medical claims."""
    fallback = f"""7-DAY WORKOUT PLAN — {goal.title()} ({intensity.title()} intensity)

Day 1 — Full-body basics
Warm-up: 5 minutes easy walking and gentle mobility.
Main: Chair squats 2×8, wall push-ups 2×8, glute bridges 2×10; easy walk 10 minutes.
Cooldown: 5 minutes gentle stretching.

Day 2 — Light cardio
Warm-up: 5 minutes easy movement.
Main: Comfortable walk or cycling for 15–25 minutes.
Cooldown: Gentle stretching.

Day 3 — Strength and mobility
Warm-up: 5 minutes.
Main: Supported lunges 2×6 each side, bird-dog 2×8 each side, calf raises 2×10.
Cooldown: 5 minutes.

Day 4 — Recovery
Main: Easy walk 10–20 minutes or relaxed mobility; rest as needed.

Day 5 — Full-body basics
Warm-up: 5 minutes.
Main: Chair squats 2×8, wall push-ups 2×8, glute bridges 2×10.
Cooldown: 5 minutes.

Day 6 — Cardio of choice
Main: Comfortable walking, dancing, or cycling for 15–25 minutes.
Cooldown: Gentle stretching.

Day 7 — Rest and reflection
Main: Rest or gentle mobility. Review how the week felt.

Adjust activity to your ability; seek advice from a qualified professional if you have health concerns."""
    return _generate(prompt, "gemini-2.5-pro", fallback)

def generate_nutrition_tip_with_flash(goal: str) -> str:
    prompt = f"Give one concise, practical, general nutrition or recovery tip for the fitness goal: {goal}. Avoid calorie prescriptions and medical claims."
    fallback = {
        "muscle gain": "Include a source of protein such as beans, eggs, dairy, tofu, or fish in balanced meals, and allow time for recovery.",
        "weight loss": "Build balanced meals with vegetables, protein, fiber-rich carbohydrates, and water; avoid extreme restriction.",
        "flexibility": "Stay hydrated and eat balanced meals; allow recovery after mobility sessions.",
        "general wellness": "Aim for regular balanced meals, enough water, and consistent sleep to support everyday activity.",
    }.get(goal.lower(), "Choose balanced meals, drink water regularly, and give your body time to recover.")
    return _generate(prompt, "gemini-2.5-flash", fallback)

def update_workout_plan(original_plan: str, feedback: str, goal: str, intensity: str) -> str:
    prompt = f"""Revise this workout plan based on user feedback. Keep it safe, practical, and 7 days long.
Goal: {goal}; intensity: {intensity}.
Original plan:
{original_plan}
Feedback:
{feedback}
Return the revised plan with warm-up, activity, and recovery details. Do not provide medical advice."""
    fallback = original_plan + f"\n\nRequested feedback: {feedback}\n[Demo mode: review and adapt the plan manually.]"
    return _generate(prompt, "gemini-2.5-pro", fallback)
