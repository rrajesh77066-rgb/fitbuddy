from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.database import SessionLocal, init_db
from app.models import User, WorkoutPlan
from app.ai_service import generate_workout_gemini, generate_nutrition_tip_with_flash, update_workout_plan

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
init_db()

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})

@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(request: Request, username: str = Form(...), user_id: str = Form(...),
                     age: int = Form(...), weight: float = Form(...), goal: str = Form(...),
                     intensity: str = Form(...)):
    if age < 13 or age > 100 or weight <= 0:
        raise HTTPException(status_code=400, detail="Please enter a valid age and weight.")
    db: Session = SessionLocal()
    try:
        user = db.query(User).filter(User.user_id == user_id.strip()).first()
        if user is None:
            user = User(user_id=user_id.strip(), username=username.strip(), age=age, weight=weight, goal=goal, intensity=intensity)
            db.add(user)
        else:
            user.username, user.age, user.weight, user.goal, user.intensity = username.strip(), age, weight, goal, intensity
        plan = generate_workout_gemini(username, age, weight, goal, intensity)
        tip = generate_nutrition_tip_with_flash(goal)
        record = WorkoutPlan(user_id=user_id.strip(), original_plan=plan, nutrition_tip=tip)
        db.add(record)
        db.commit()
        db.refresh(record)
        return templates.TemplateResponse(request=request, name="result.html", context={
            "username": username, "user_id": user_id.strip(), "goal": goal, "intensity": intensity,
            "workout_plan": plan, "nutrition_tip": tip, "plan_id": record.id
        })
    finally:
        db.close()

@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(request: Request, plan_id: int = Form(...), feedback: str = Form(...)):
    db: Session = SessionLocal()
    try:
        record = db.query(WorkoutPlan).filter(WorkoutPlan.id == plan_id).first()
        if not record:
            raise HTTPException(status_code=404, detail="Workout plan not found.")
        user = db.query(User).filter(User.user_id == record.user_id).first()
        revised = update_workout_plan(record.original_plan, feedback, user.goal if user else "general wellness", user.intensity if user else "low")
        record.feedback = feedback
        record.updated_plan = revised
        db.commit()
        return templates.TemplateResponse(request=request, name="result.html", context={
            "username": user.username if user else "User", "user_id": record.user_id,
            "goal": user.goal if user else "general wellness", "intensity": user.intensity if user else "low",
            "workout_plan": record.original_plan, "updated_plan": revised,
            "nutrition_tip": record.nutrition_tip, "plan_id": record.id
        })
    finally:
        db.close()

@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request):
    db: Session = SessionLocal()
    try:
        users = db.query(User).order_by(User.id.desc()).all()
        plans = db.query(WorkoutPlan).order_by(WorkoutPlan.id.desc()).all()
        return templates.TemplateResponse(request=request, name="all_users.html", context={"users": users, "plans": plans})
    finally:
        db.close()

@router.post("/delete-user/{user_id}")
def delete_user(user_id: str):
    db: Session = SessionLocal()
    try:
        db.query(WorkoutPlan).filter(WorkoutPlan.user_id == user_id).delete()
        db.query(User).filter(User.user_id == user_id).delete()
        db.commit()
        return RedirectResponse(url="/view-all-users", status_code=303)
    finally:
        db.close()
