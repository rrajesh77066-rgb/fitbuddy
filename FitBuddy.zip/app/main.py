from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.routes import router

app = FastAPI(title="FitBuddy - AI Fitness Plan Generator", version="1.0.0")
app.include_router(router)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
