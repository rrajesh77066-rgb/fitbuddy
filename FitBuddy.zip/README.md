# FitBuddy — AI Fitness Plan Generator

A FastAPI + Jinja2 web app that creates a 7-day workout plan, provides a nutrition/recovery tip, accepts feedback to revise a plan, and stores users/plans in SQLite.

## Requirements
- Python 3.11 or newer (Python 3.12/3.13 recommended)
- VS Code (optional)
- Internet connection for installing packages and using Gemini

## Run on Windows (easy way)
1. Extract `FitBuddy.zip` to a folder.
2. Open that folder in VS Code.
3. Double-click `run_windows.bat`, or use the commands below in the VS Code terminal.
4. Open http://127.0.0.1:8000

## Run manually in VS Code terminal
```powershell
python -m venv venv
.\venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
python -m uvicorn app.main:app --reload
```
Then open:
- App: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Admin dashboard: http://127.0.0.1:8000/view-all-users

## Enable Gemini AI
1. Get an API key from Google AI Studio.
2. Open `.env` and set `GOOGLE_API_KEY=your_key_here`.
3. Stop the server with `Ctrl+C`, then run it again.

Without a key, the app still runs using built-in demo workout/nutrition content. With a key, it attempts Gemini `gemini-2.5-pro` for workout plans and updates, and `gemini-2.5-flash` for nutrition tips.

## Features
- User details form and 7-day plan generation
- Goal-based nutrition/recovery tip
- Feedback-based plan update
- SQLite persistence
- Admin view and delete action

## Notes
- The admin page is not password-protected; use only for local demonstration.
- This is general fitness information, not medical advice. Use appropriate activities and consult a qualified professional if you have health concerns.
